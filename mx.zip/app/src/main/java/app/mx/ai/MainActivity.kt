package app.mx.ai

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily

object Cfg {
    const val URL = "https://rkifqclniesvytqkfhhz.supabase.co"
    const val ANON = "sb_publishable_ix52fuzf7JiErQuEfOO2vA_tP7R7BgO"
}

object Api {
    val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).callTimeout(40, TimeUnit.SECONDS).build()
    private val stream = http.newBuilder().readTimeout(0, TimeUnit.SECONDS).callTimeout(0, TimeUnit.SECONDS).build()
    private val JSON = "application/json".toMediaType()
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("mx", 0) }
    val loggedIn get() = sp.getString("t", null) != null
    fun logout() { sp.edit().clear().apply() }

    fun req(path: String, body: String? = null, auth: Boolean = true, del: Boolean = false): Request {
        val b = Request.Builder().url(Cfg.URL + path).header("apikey", Cfg.ANON)
        val tok = sp.getString("t", null)
        if (auth && tok != null) b.header("Authorization", "Bearer " + tok)
        if (body != null) b.post(body.toRequestBody(JSON))
        if (del) b.delete()
        return b.build()
    }
    private fun save(j: JSONObject) {
        sp.edit().putString("t", j.getString("access_token")).putString("r", j.optString("refresh_token"))
            .putString("u", j.getJSONObject("user").getString("id")).apply()
    }
    fun login(email: String, pass: String, signup: Boolean): String? = try {
        val path = if (signup) "/auth/v1/signup" else "/auth/v1/token?grant_type=password"
        val body = JSONObject().put("email", email).put("password", pass).toString()
        http.newCall(req(path, body, false)).execute().use { r ->
            val j = JSONObject(r.body!!.string())
            if (j.has("access_token")) { save(j); null }
            else if (signup && r.isSuccessful) "تحقق من بريدك لتأكيد الحساب ثم سجّل الدخول"
            else j.optString("msg", j.optString("error_description", "فشل الدخول"))
        }
    } catch (e: Exception) { "تحقق من الإنترنت" }

    private fun refresh(): Boolean = try {
        val b = JSONObject().put("refresh_token", sp.getString("r", "")).toString()
        http.newCall(req("/auth/v1/token?grant_type=refresh_token", b, false)).execute().use { r ->
            val j = JSONObject(r.body!!.string())
            if (j.has("access_token")) { save(j); true } else false
        }
    } catch (e: Exception) { false }

    /** returns (conversationId, error). error == "limit" when the daily limit is reached */
    fun chat(conv: String?, msg: String, onTok: (String) -> Unit): Pair<String?, String?> {
        for (attempt in 0..1) {
            try {
                val body = JSONObject().put("message", msg).apply { if (conv != null) put("conversation_id", conv) }.toString()
                stream.newCall(req("/functions/v1/chat", body)).execute().use { r ->
                    if (r.code == 401 && attempt == 0 && refresh()) return@use
                    if (r.code == 429) return conv to "limit"
                    if (!r.isSuccessful) return conv to "خطأ بالخادم، حاول مرة ثانية"
                    var id = conv
                    val src = r.body!!.source()
                    while (true) {
                        val line = src.readUtf8Line() ?: break
                        if (!line.startsWith("data: ")) continue
                        val j = JSONObject(line.substring(6))
                        if (j.has("t")) onTok(j.getString("t"))
                        if (j.optBoolean("done")) id = j.getString("conversation_id")
                    }
                    return id to null
                }
            } catch (e: Exception) { return conv to "تحقق من الإنترنت" }
        }
        return conv to "انتهت الجلسة، سجّل الدخول مجدداً"
    }

    fun isOwner(): Boolean = try {
        http.newCall(req("/rest/v1/profiles?select=role&id=eq." + sp.getString("u", ""))).execute().use { r ->
            JSONArray(r.body!!.string()).optJSONObject(0)?.optString("role") == "owner"
        }
    } catch (e: Exception) { false }

    fun revenue(): JSONObject? = try {
        http.newCall(req("/rest/v1/rpc/owner_revenue", "{}")).execute().use { r ->
            JSONArray(r.body!!.string()).optJSONObject(0)
        }
    } catch (e: Exception) { null }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Api.init(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Color(0xFF0B0B0C), surface = Color(0xFF0B0B0C))) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(Modifier.fillMaxSize()) { Root() }
                }
            }
        }
    }
}

@Composable fun Root() {
    var screen by remember { mutableStateOf(if (Api.loggedIn) "chat" else "login") }
    val msgs = remember { mutableStateListOf<Msg>() }
    var conv by remember { mutableStateOf<String?>(null) }
    fun newChat() { msgs.clear(); conv = null; screen = "chat" }
    when (screen) {
        "login" -> Login { screen = "chat" }
        "history" -> History({ screen = "chat" }, { newChat() }) { id, list ->
            msgs.clear(); msgs.addAll(list); conv = id; screen = "chat"
        }
        "plans" -> Plans { screen = "chat" }
        "admin" -> Admin { screen = "chat" }
        else -> Chat(msgs, conv, { conv = it }, { newChat() }, { screen = it }) {
            Api.logout(); msgs.clear(); conv = null; screen = "login"
        }
    }
}

@Composable fun Login(onOk: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun go(signup: Boolean) {
        busy = true
        scope.launch(Dispatchers.IO) {
            val e = Api.login(email.trim(), pass, signup)
            withContext(Dispatchers.Main) { busy = false; err = e; if (e == null) onOk() }
        }
    }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("MX", fontSize = 46.sp, fontWeight = FontWeight.Bold)
        Text("ذكاء اصطناعي", color = Color.Gray)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("البريد الإلكتروني") }, singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), label = { Text("كلمة المرور") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation())
        err?.let { Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.padding(top = 10.dp)) }
        Spacer(Modifier.height(18.dp))
        Button({ go(false) }, Modifier.fillMaxWidth(), enabled = !busy) { Text("دخول") }
        TextButton({ go(true) }, enabled = !busy) { Text("إنشاء حساب جديد") }
    }
}

data class Msg(val mine: Boolean, val text: String)

@Composable fun Chat(
    msgs: SnapshotStateList<Msg>, conv: String?, setConv: (String?) -> Unit,
    onNew: () -> Unit, go: (String) -> Unit, onLogout: () -> Unit
) {
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var limit by remember { mutableStateOf(false) }
    var owner by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    val clip = LocalClipboardManager.current
    val ctx = LocalContext.current
    LaunchedEffect(Unit) { owner = withContext(Dispatchers.IO) { Api.isOwner() } }
    LaunchedEffect(msgs.size, msgs.lastOrNull()?.text) { if (msgs.isNotEmpty()) list.scrollToItem(msgs.size - 1) }

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        input = ""; busy = true; limit = false
        msgs.add(Msg(true, t)); msgs.add(Msg(false, ""))
        scope.launch(Dispatchers.IO) {
            val (id, e) = Api.chat(conv, t) { tok ->
                val i = msgs.lastIndex; msgs[i] = Msg(false, msgs[i].text + tok)
            }
            withContext(Dispatchers.Main) {
                setConv(id)
                if (e == "limit") { limit = true; msgs.removeAt(msgs.lastIndex); msgs.removeAt(msgs.lastIndex); input = t }
                else if (e != null) msgs[msgs.lastIndex] = Msg(false, e)
                busy = false
            }
        }
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("MX ذكاء اصطناعي", fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
            TextButton(onNew) { Text("+ جديدة") }
            Box {
                TextButton({ menu = true }) { Text("⋮", fontSize = 20.sp) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("المحادثات") }, onClick = { menu = false; go("history") })
                    DropdownMenuItem(text = { Text("الخطط والاشتراك") }, onClick = { menu = false; go("plans") })
                    if (owner) DropdownMenuItem(text = { Text("لوحة الأرباح") }, onClick = { menu = false; go("admin") })
                    DropdownMenuItem(text = { Text("تسجيل الخروج") }, onClick = { menu = false; onLogout() })
                }
            }
        }
        if (msgs.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("MX", fontSize = 40.sp, fontWeight = FontWeight.Bold)
                Text("كيف أكدر أساعدك اليوم؟", color = Color.Gray)
                Spacer(Modifier.height(20.dp))
                listOf("اكتب لي رسالة رسمية مهذبة", "اشرح لي فكرة بشكل مبسّط", "ساعدني بكتابة كود برمجي", "أعطني أفكار لمشروع ناجح").forEach { s ->
                    OutlinedButton({ send(s) }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(s) }
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = list, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(msgs) { m ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.mine) Alignment.CenterStart else Alignment.CenterEnd) {
                        Surface(
                            shape = RoundedCornerShape(16.dp), color = if (m.mine) Color.White else Color(0xFF1E1E22),
                            modifier = Modifier.widthIn(max = 310.dp).pointerInput(m.text) {
                                detectTapGestures(onLongPress = {
                                    clip.setText(AnnotatedString(m.text))
                                    Toast.makeText(ctx, "تم النسخ", Toast.LENGTH_SHORT).show()
                                })
                            }
                        ) { Rich(m.text.ifEmpty { "…" }, if (m.mine) Color.Black else Color.White) }
                    }
                }
            }
        }
        if (limit) Card(Modifier.fillMaxWidth().padding(12.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("انتهت رسائلك لليوم", fontWeight = FontWeight.Bold)
                Text("اشترك بخطة Plus أو Pro للمتابعة، أو ارجع باجر.", color = Color.Gray)
                Button({ go("plans") }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("عرض الخطط") }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("اكتب رسالتك…") }, maxLines = 4)
            Spacer(Modifier.width(8.dp))
            Button({ send(input) }, enabled = !busy) { Text("إرسال") }
        }
    }
}

@Composable fun Rich(text: String, color: Color) {
    Column(Modifier.padding(12.dp)) {
        text.split("```").forEachIndexed { i, part ->
            if (i % 2 == 1) {
                val code = part.substringAfter("\n", part).trimEnd()
                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF0B0B0C), modifier = Modifier.padding(vertical = 4.dp).fillMaxWidth()) {
                    Text(code, color = Color(0xFFE6E6E6), fontFamily = FontFamily.Monospace, fontSize = 13.sp, modifier = Modifier.padding(10.dp))
                }
            } else if (part.isNotBlank()) {
                Text(part.trim(), color = color)
            }
        }
    }
}

@Composable fun Admin(onBack: () -> Unit) {
    var d by remember { mutableStateOf<JSONObject?>(null) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { d = withContext(Dispatchers.IO) { Api.revenue() }; loaded = true }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
        TextButton(onBack) { Text("رجوع") }
        Text("لوحة الأرباح", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        val x = d
        if (x == null) Text(if (loaded) "غير مسموح أو لا توجد بيانات" else "جاري التحميل…", color = Color.Gray)
        else listOf("الدخل الإجمالي" to "gross_iqd", "العمولات" to "fees_iqd", "تكلفة الذكاء" to "ai_cost_iqd",
            "الربح الصافي" to "net_iqd", "صافي هذا الشهر" to "month_net_iqd", "المشتركون النشطون" to "active_subscribers"
        ).forEach { (l, k) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
                Text(l, Modifier.weight(1f))
                Text("%,d".format(x.optLong(k)) + if (k == "active_subscribers") "" else " د.ع", fontWeight = FontWeight.Bold)
            }
        }
    }
}

object Data {
    private fun arr(path: String): JSONArray? = try {
        Api.http.newCall(Api.req(path)).execute().use { r -> if (r.isSuccessful) JSONArray(r.body!!.string()) else null }
    } catch (e: Exception) { null }

    fun conversations(): List<Pair<String, String>> {
        val a = arr("/rest/v1/conversations?select=id,title&order=created_at.desc&limit=50") ?: return emptyList()
        return (0 until a.length()).map { val o = a.getJSONObject(it); o.getString("id") to o.optString("title", "") }
    }
    fun messages(cid: String): List<Msg> {
        val a = arr("/rest/v1/messages?select=role,content&conversation_id=eq.$cid&order=created_at.asc&limit=200") ?: return emptyList()
        return (0 until a.length()).map { val o = a.getJSONObject(it); Msg(o.getString("role") == "user", o.getString("content")) }
    }
    fun plans(): List<JSONObject> {
        val a = arr("/rest/v1/plans?select=*&order=price_iqd.asc") ?: return emptyList()
        return (0 until a.length()).map { a.getJSONObject(it) }
    }
    fun usedToday(): Int {
        val f = SimpleDateFormat("yyyy-MM-dd", Locale.US); f.timeZone = TimeZone.getTimeZone("UTC")
        return arr("/rest/v1/usage_log?select=id&day=eq." + f.format(Date()))?.length() ?: 0
    }
    fun delete(cid: String) {
        try { Api.http.newCall(Api.req("/rest/v1/conversations?id=eq.$cid", null, true, true)).execute().close() } catch (e: Exception) { }
    }
}

@Composable fun History(onBack: () -> Unit, onNew: () -> Unit, onOpen: (String, List<Msg>) -> Unit) {
    var list by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) { list = withContext(Dispatchers.IO) { Data.conversations() } }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onBack) { Text("رجوع") }
            Spacer(Modifier.weight(1f))
            Button(onNew) { Text("محادثة جديدة") }
        }
        Text("المحادثات", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        val l = list
        if (l == null) Text("جاري التحميل…", color = Color.Gray)
        else if (l.isEmpty()) Text("ماكو محادثات بعد", color = Color.Gray)
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(l) { (id, title) ->
                Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFF1E1E22), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 14.dp, top = 4.dp, bottom = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(title.ifEmpty { "محادثة" }, maxLines = 1, modifier = Modifier.weight(1f).clickable {
                            scope.launch(Dispatchers.IO) {
                                val m = Data.messages(id)
                                withContext(Dispatchers.Main) { onOpen(id, m) }
                            }
                        }.padding(vertical = 12.dp))
                        TextButton({
                            scope.launch(Dispatchers.IO) {
                                Data.delete(id)
                                val n = Data.conversations()
                                withContext(Dispatchers.Main) { list = n }
                            }
                        }) { Text("حذف", color = Color(0xFFFF6B6B)) }
                    }
                }
            }
        }
    }
}

@Composable fun Plans(onBack: () -> Unit) {
    var plans by remember { mutableStateOf<List<JSONObject>?>(null) }
    var used by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        val p = withContext(Dispatchers.IO) { Data.plans() }
        val u = withContext(Dispatchers.IO) { Data.usedToday() }
        plans = p; used = u
    }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
        TextButton(onBack) { Text("رجوع") }
        Text("الخطط والاشتراك", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("رسائل اليوم: " + used, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
        val p = plans
        if (p == null) Text("جاري التحميل…", color = Color.Gray)
        else p.forEach { o ->
            val price = o.optInt("price_iqd")
            Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(o.optString("name"), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text(if (price == 0) "مجاناً" else "%,d د.ع / شهر".format(price))
                    Text(o.optInt("message_limit").toString() + " رسالة باليوم", color = Color.Gray)
                    if (price > 0) Button({}, Modifier.fillMaxWidth().padding(top = 8.dp), enabled = false) { Text("اشترك — قريباً") }
                }
            }
        }
    }
}
